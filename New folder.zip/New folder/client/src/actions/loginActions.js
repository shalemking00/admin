import axios from 'axios'
export const userLogin=(user)=>async(dispatch)=>{
    dispatch({type:'USER_LOGIN_REQUEST'});
    try {
        const response=await axios.post('http://localhost:7000/api/auth/login',user)
        dispatch({type:'USER_LOGIN_SUCCESS',payload:response.data});
        localStorage.setItem('currentUser',JSON.stringify(response.data))
        window.location.href='/'
        console.log(response)

        
    } catch (error) {
        dispatch({type:'USER_LOGIN_FAILED',payload:error})
        console.log(error)
        
    }
}

export const logout=()=>(dispatch)=>{
    localStorage.removeItem('currentUser');
    window.location.href='/login'
    // dispatch({type:'LOGOUT'})
    
   
}