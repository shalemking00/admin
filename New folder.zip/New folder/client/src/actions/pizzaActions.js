import axios from "axios";
export const getAllPizzas=async dispatch=>{
    dispatch({type:'GET_PIZZAS_REQUEST'})
    try {
        const pizzas=await axios.get('http://localhost:7000/api/pizzas/getAllpizzas')
        console.log(pizzas);
        dispatch({type:'GET_PIZZAS_SUCCESS',payload:pizzas.data})
        
    } catch (error) {
        dispatch({type:'GET_PIZZAS_FAILED',payload:error});
        console.log(error)
    }
}

export const filterPizzas=(searchKey,category)=>async dispatch=>{
    var filteredPizzas
    dispatch({type:'GET_PIZZAS_REQUEST'})
    try {
        const pizzas=await axios.get('http://localhost:7000/api/pizzas/getAllpizzas')
        filteredPizzas=pizzas.data.filter(pizza=>pizza.name.toLowerCase().includes(searchKey))

        if(category!=='all'){
            filteredPizzas=pizzas.data.filter(pizza=>pizza.category.toLowerCase()===category)

        }


        console.log(pizzas);
        dispatch({type:'GET_PIZZAS_SUCCESS',payload:filteredPizzas})
        
    } catch (error) {
        dispatch({type:'GET_PIZZAS_FAILED',payload:error});
        console.log(error)
    }
}

export const addPizza=(pizza)=>async dispatch=>{
    dispatch({type:'ADD_PIZZA_REQUEST'})
    try {
        const response=await axios.post('http://localhost:7000/api/pizzas/addpizza',{pizza})
        
        dispatch({type:'ADD_PIZZA_SUCCESS'})
        console.log(response)
        
    } catch (error) {
        dispatch({type:'ADD_PIZZA_FAILED',payload:error});
        console.log(error)
    }


}



export const editPizza=(updatedPizza)=>async dispatch=>{
    dispatch({type:'EDIT_PIZZA_REQUEST'})
    try {
        const response=await axios.post('http://localhost:7000/api/pizzas/editpizza',{updatedPizza})
        
        dispatch({type:'EDIT_PIZZA_SUCCESS'})
        window.location.href='/admin/pizzaslist'
        console.log(response)
        
    } catch (error) {
        dispatch({type:'EDIT_PIZZA_FAILED',payload:error});
        console.log(error)
    }


}

export const getPizzaById=(id)=>async dispatch=>{
    dispatch({type:'GET_PIZZABYID_REQUEST'})
    try {
        const pizza=await axios.post('http://localhost:7000/api/pizzas/getpizzabyid',{id})
        console.log(pizza.data);
        dispatch({type:'GET_PIZZABYID_SUCCESS',payload:pizza.data})
        
    } catch (error) {
        dispatch({type:'GET_PIZZABYID_FAILED',payload:error});
        console.log(error)
    }
}

export const deletePizza=(id)=>async dispatch=>{
    
    try {
        const pizza=await axios.post('http://localhost:7000/api/pizzas/deletepizza',{id})
        console.log(pizza.data);
        alert('pizza Deleted successfully')
        
        window.location.reload()
       
        
    } catch (error) {
       alert('something Went wrong');
        console.log(error)
    }
}