import axios from 'axios'
export const placeOrder = (token,subtotal) =>async(dispatch,getState)=>{
    dispatch({type:'PLACE_ORDER_REQUEST'})
    const currentUser=getState().LoginReducer.currentUser
    const cartItems=getState().cartReducer.cartItems
    try {
        const response=await axios.post('http://localhost:7000/api/orders/placeorder',{token,subtotal,currentUser,cartItems})
        dispatch({type:'PLACE_ORDER_SUCCESS'})
        console.log(response)
        
    } catch (error) {
        dispatch({type:'PLACE_ORDER_FAILED'})
        console.log(error)

        
    }

}

export const getAllOrders=()=>async(dispatch,getState)=>{
    const currentUser=getState().LoginReducer.currentUser
    dispatch({type:'GET_ORDERS_REQUEST'})
    try {
        const response=await axios.post('http://localhost:7000/api/orders/myorders',{userid:currentUser._id})
        console.log(response);
        dispatch({type:'GET_ORDERS_SUCCESS',payload:response.data})
        
    } catch (error) {
        dispatch({type:'GET_ORDERS_FAILED',payload:error});
        console.log(error)
    }
}

export const getOrders=()=>async(dispatch,getState)=>{
    const currentUser=getState().LoginReducer.currentUser
    dispatch({type:'GET_ALL_ORDERS_REQUEST'})
    try {
        const response=await axios.get('http://localhost:7000/api/orders/allorders')
        console.log(response);
        dispatch({type:'GET_ALL_ORDERS_SUCCESS',payload:response.data})
        
    } catch (error) {
        dispatch({type:'GET_ALL_ORDERS_FAILED',payload:error});
        console.log(error)
    }
}

export const deliverOrder=(id)=>async dispatch=>{
    try {
        const response=await axios.post('http://localhost:7000/api/orders/deliverorder',{id})
        console.log(response);
        alert('order delivered successfull')
        const orders=await axios.get('http://localhost:7000/api/orders/allorders')
        dispatch({type:'GET_ALL_ORDERS_SUCCESS',payload:orders.data})
    } catch (error) {
        console.log(error)
    }

}