import axios from "axios"
export const registeredUser = (user)=>async(dispatch) => {
    dispatch({type:'USER_REGISTER_REQUEST'})
    try {
        const response=await axios.post('http://localhost:7000/api/user/register',user)
        dispatch({type:'USER_REGISTER_SUCCESS'});
        console.log(response)

        
    } catch (error) {
        dispatch({type:'USER_REGISTER_FAILED'})

        console.log(error)
    }
}

