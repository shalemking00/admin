import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../actions/loginActions";

const Navbar = () => {
  const cartState = useSelector((state) => state.cartReducer);
  const loginstate = useSelector((state) => state.LoginReducer);
  const { currentUser } = loginstate;
  const dispatch = useDispatch();
  return (
    <div>
      <nav className="navbar navbar-expand-lg shadow p-3 mb-5 bg-body rounded ">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">
            Pizza-King
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              {currentUser ? (
                <>
                  <li className="nav-item">
                    <a className="nav-link" href="/cart">
                      Cart {cartState.cartItems.length}
                    </a>
                  </li>
                  <div className="dropdown">
                    <a
                      className="nav-link dropdown-toggle"
                      type="button"
                      id="dropdownMenuButton"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      {currentUser.name}
                    </a>
                    <div
                      className="dropdown-menu"
                      aria-labelledby="dropdownMenuButton"
                    >
                      <a className="dropdown-item" href="/orders">
                        orders
                      </a>
                      <a
                        className="dropdown-item"
                        onClick={() => dispatch(logout())}
                      >
                        <li>Logout</li>
                      </a>
                    </div>
                  </div>
                </>
              ) : (
                <>
                <li className="nav-item">
                  <a className="nav-link " href="/login">
                    Login
                  </a>
                </li>
                <li className="nav-item">
                <a className="nav-link" href="#">
                  Cart{" "}
                </a>
              </li>
              </>
              )}

              
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
