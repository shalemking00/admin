import React from 'react'
import { useState,useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { registeredUser } from '../actions/userActions';
import Success from './Success';
import Loading from './Loading';
import Error from './Error';

const Register = () => {
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [password,setPassword]=useState('');
    const [cpassword,setCpassword]=useState('');
    const dispatch=useDispatch()
    const registerstate=useSelector(state=>state.userReducer)
    const {error,loading,success}=registerstate

    const register=()=>{
       
        if(password!==cpassword){
            alert('passwords not matched');

        }else{
            const user={
                name,
                email,password
            }
            console.log(user);
            dispatch(registeredUser(user))
        }
    }
    
  return (
    <div>
        <div className='row justify-content-center mt-5'>
            <div className='col-md-5 mt-5 text-left shadow p-3 mb-5 bg-white rounded'>
                {loading &&(<Loading/>)}
                {success &&(<Success success='Registered Succesfully'/>)}
                {error && (<Error error='user already Exists'/>)}
                <h2 className='text-center'>Register</h2>
                <div>
                    <input required type="text" placeholder='name' className='form-control' value={name} onChange={(e)=>setName(e.target.value)}/>
                    <input required type="email" placeholder='email' className='form-control'value={email} onChange={(e)=>setEmail(e.target.value)}/>
                    <input required type="password" placeholder='password' className='form-control'value={password} onChange={(e)=>setPassword(e.target.value)}/>
                    <input required type="password" placeholder='confirmpassword' className='form-control' value={cpassword} onChange={(e)=>setCpassword(e.target.value)}/>
                    <button className='btn btn- mt-3' onClick={register}>Register</button>
                    <a href='/login' style={{margin:'30px'}}>click here to Login?</a>
                </div>

            </div>

        </div>
    </div>
  )
}

export default Register