import React, { useEffect } from 'react'

import Pizza from './Pizza'
import {useDispatch,useSelector} from "react-redux"
import { getAllPizzas } from '../actions/pizzaActions'
import Loading from './Loading'
import Error from './Error'
import Filter from './Filter'

const Home = () => {
    const dispatch=useDispatch()
    const pizzasstate=useSelector(state=>state.getAllPizzasReducer)

    const{pizzas,error,loading}=pizzasstate

    useEffect(()=>{
        dispatch(getAllPizzas)
       

    },[])
    
  return (
      <div>
          <Filter/>
          <div className='row justify-content-center'>
              
              {loading ? (<Loading/>): error?(<Error error='something went Wrong please!'/>):(
                  pizzas.map((pizza)=>{
                    return <div key={pizza._id} className='col-md-3 m-3'>
                        <div >
                            <Pizza pizza={pizza}/>
                        </div>
                        
                    </div>
  
                })




              )}




              

          </div>
      </div>
    





   
  )
}

export default Home