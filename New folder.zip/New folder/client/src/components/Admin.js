import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import AddPizza from "./AddPizza";
import OrdersList from "./OrdersList";
import PizzasList from "./PizzasList";
import UsersList from "./UsersList";
import {BrowserRouter,Routes,Route, Link} from 'react-router-dom'
import Editpizza from "./Editpizza";

const Admin = () => {
  const loginstate = useSelector((state) => state.LoginReducer);
  const { currentUser } = loginstate;
  const dispatch = useDispatch();

  useEffect(() => {
    if (!currentUser.isAdmin) {
      window.location.href = "/";
    }
  }, []);

  return (
    <div>
      <div className="row justify-content-center">
        <div className="col-md-10">
          <h2 style={{ fontSize: "35px" }}>Admin Panel</h2>
          <ul className="adminfunction">
            <li>
              <Link  to="/admin/userslist">Users List</Link>
            </li>
            <li>
            <Link to="/admin/pizzaslist">Pizzas List</Link>
            </li>
            <li>
            <Link to="/admin/addpizza">Add Pizza</Link>
              
            </li>
            <li>
              <Link to="/admin/orderslist">Orders List</Link>
            </li>
          </ul>

         
            <Routes>
                <Route path='/'  element={<UsersList/>}/>
                <Route path='/userslist'  element={<UsersList/>}/>
                <Route path='/pizzaslist' exact element={<PizzasList/>}/>
                <Route path='/addpizza' exact element={<AddPizza/>}/>
                <Route path='/orderslist' exact element={<OrdersList/>}/>
                <Route path='/editpizza/:pizzaid'  element={<Editpizza/>}/>
            </Routes>
          
          
          
         

          




        </div>
      </div>
    </div>
  );
};

export default Admin;
