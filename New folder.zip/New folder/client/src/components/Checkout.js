import React from 'react'
import StripeCheckout from 'react-stripe-checkout'
import {useDispatch,useSelector} from 'react-redux'
import { placeOrder } from '../actions/orderActions'
import Loading from './Loading'
import Success from './Success'
import Error from './Error'

const Checkout = ({subtotal}) => {
  const dispatch=useDispatch()
  const orderState=useSelector(state=>state.orderReducer)
  const {loading,error,success}=orderState
    const tokenHandler=(token)=>{
        console.log(token)
        dispatch(placeOrder(token,subtotal))

    }

  return (
    <div>
      {loading && (<Loading/>)}
      {success && (<Success success='Order placed succesfully'/>)}
      {error&&(<Error error='something went wrong'/>)}
        <StripeCheckout amount={subtotal*100} shippingAddress stripeKey='pk_test_51KksavSFsKttunbChKImZeEObVa5J6nXFR5xY3tao9p6LrQrQoQRavu65EOgPGHBBLkxw5FQdGg9DgzF1pJZgDOx00gmkwJc0t' token={tokenHandler} currency='INR'>
            <button className='btn'>Pay Now</button>
        </StripeCheckout>
    </div>
  )
}

export default Checkout