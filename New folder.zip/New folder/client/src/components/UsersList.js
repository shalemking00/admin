import React from 'react'

const UsersList = () => {
  return (
    <div>
        <h1>UsersList</h1>
    </div>
  )
}

export default UsersList