import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getAllOrders } from '../actions/orderActions'
import Error from './Error'
import Loading from './Loading'

const Orders = () => {
    const dispatch=useDispatch()
    const orderState=useSelector(state=>state.getOrderReducer)
    const{orders,error,loading}=orderState
    useEffect(()=>{
        dispatch(getAllOrders())
    },[])
  return (
    <div>
        <h2 style={{fontSize:'35px'}}>MY ORDERS</h2><hr/>
        <div className='row justify-content-center'>
            {loading &&(<Loading/>)}
            {error && (<Error error='something went wrong'/>)}
            {orders && orders.map((order,i)=>{
                return <div className='col-md-9 m-2' style={{backgroundColor:'red',color:'white',borderRadius:'2px'}}>
                    <div className='mt-2 flex-container'>
                        <div className='text-left w-100 m-1' style={{textAlign:'left'}}>
                            <h2 style={{fontSize:'25px'}}>Items</h2><hr/>
                            {order.orderItems.map((item,i)=>{
                                return <ul>
                                    <li><p>{item.name}[{item.varient}]*{item.quantity}={item.price}/-</p></li>

                                </ul>
                            })}

                        </div>
                        <div className='text-left w-100 m-1' style={{textAlign:'left'}}>
                            <h2 style={{fontSize:'25px'}}>Address</h2><hr/>
                            <p>Street:{order.shippingAddress.street}</p>
                            <p>City:{order.shippingAddress.city}</p>
                            <p>Country:{order.shippingAddress.country}</p>

                        </div>
                        <div className='text-left w-100 m-1' style={{textAlign:'left'}}>
                            <h2 style={{fontSize:'25px'}}>OrderInfo</h2><hr/>
                            <p>Order Amount:{order.orderAmount}/-</p>
                            <p>Date:{order.createdAt.substring(0,10)}</p>
                            <p>TransactionId:{order.transactionId}</p>
                            <p>OrderId:{order._id}</p>




                        </div>
                    </div>
                </div>
            })}
        </div>
    </div>
  )
}

export default Orders