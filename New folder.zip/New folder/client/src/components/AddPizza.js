import React, { useState } from 'react'
import { useDispatch,useSelector } from 'react-redux';
import { addPizza } from '../actions/pizzaActions';
import Loading from './Loading';
import Error from './Error';
import Success from './Success';

const AddPizza = () => {
  const [name,setName]=useState('');
  const [smallprice,setSmallprice]=useState()
  const [mediumprice,setMediumprice]=useState()
  const [largeprice,setLargeprice]=useState()
  const [image,setImage]=useState('');
  const [desc,setDesc]=useState('');
  const [category,setCategory]=useState('')
  const dispatch=useDispatch();
  const addpizzastate=useSelector(state=>state.addpizzaReducer);

  const {loading,error,success}=addpizzastate

  const submitHandler=(e)=>{
    e.preventDefault();
    const pizza={
      name,
      image,
      desc,category,
      prices:{
        small:smallprice,
        medium:mediumprice,
        large:largeprice
      }
    }
    console.log(pizza)
    dispatch(addPizza(pizza))


  }


  return (
    <div>
      <div style={{textAlign:'left'}}>
        <h2>Add Pizza</h2>
        {loading && (<Loading/>)}
        {error && (<Error error='something went wrong'/>) }
        {success &&(<Success success='New pizza added succesfully'/>)}
        <form onSubmit={submitHandler}>
          <input type='text' className='form-control' value={name} placeholder='pizza name' onChange={(e)=>setName(e.target.value)}/>
          <input type='text' className='form-control' value={smallprice} placeholder='small price' onChange={(e)=>setSmallprice(e.target.value)}/>
          <input type='text' className='form-control' value={mediumprice} placeholder='medium price' onChange={(e)=>setMediumprice(e.target.value)}/>
          <input type='text' className='form-control' value={largeprice} placeholder='large price' onChange={(e)=>setLargeprice(e.target.value)}/>
          <input type='text' className='form-control' value={image} placeholder='image url' onChange={(e)=>setImage(e.target.value)}/>
          <input type='text' className='form-control' value={desc} placeholder='Description' onChange={(e)=>setDesc(e.target.value)}/>
          <input type='text' className='form-control' value={category} placeholder='category' onChange={(e)=>setCategory(e.target.value)}/>
          <button type='submit' className='btn mt-3'>Add Pizza</button>





        </form>
      </div>
    </div>
  )
}

export default AddPizza