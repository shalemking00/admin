import React, { useEffect } from 'react'
import { useState } from 'react'
import { useDispatch,useSelector } from 'react-redux';
import { userLogin } from '../actions/loginActions';
import Loading from './Loading';
import Error from './Error';
import Success from './Success';

const Login = () => {
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const dispatch=useDispatch();
  const loginstate=useSelector(state=>state.LoginReducer)
  const{loading,error}=loginstate

  useEffect(()=>{
    if(localStorage.getItem('currentUser')){
      window.location.href='/';
    }


  },[])

  const loginHandler=()=>{
    if(email === '' || password===''){
      alert('please provide valid credentials')
    }
     
    else{
      const user={
        email,password
      }
      dispatch(userLogin(user))
    
    }


  }



  return (
    <div>
    <div className='row justify-content-center mt-5'>
        <div className='col-md-5 mt-5 text-left shadow p-3 mb-5 bg-white rounded'>
          {loading&&(<Loading/>)}
          {error &&(<Error error='invalid username or password'/>)}

            <h2 className='text-center'>Login</h2>
            <div>
                <input required type="email" placeholder='email' className='form-control' value={email} onChange={(e)=>setEmail(e.target.value)}/>
                <input required type="password" placeholder='password' className='form-control'value={password} onChange={(e)=>setPassword(e.target.value)}/>
         
                <button className='btn btn- mt-3' onClick={loginHandler}>Login</button>
                <a style={{marginLeft:'10px',marginTop:'30px'}} href='/register'>click here to Register</a>
            </div>

        </div>

    </div>
</div>
  )
}

export default Login