import React, { useEffect,useState } from 'react'
import { useDispatch,useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { editPizza, getPizzaById } from '../actions/pizzaActions'
import Loading from './Loading'
import Error from './Error'
import Success from './Success'

const Editpizza = ({match}) => {
    const params=useParams()
    const dispatch=useDispatch();
    const id=params.pizzaid
    const pizzabyidstate=useSelector(state=>state.getpizzabyidReducer)
    const {loading,error,pizza}=pizzabyidstate

    const editpizzastate=useSelector(state=>state.editPizzaReducer)

    const{editloading,editerror,editsuccess}=editpizzastate

    const [name,setName]=useState('');
  const [smallprice,setSmallprice]=useState()
  const [mediumprice,setMediumprice]=useState()
  const [largeprice,setLargeprice]=useState()
  const [image,setImage]=useState('');
  const [desc,setDesc]=useState('');
  const [category,setCategory]=useState('')

    useEffect(()=>{
        if(pizza){
            if(pizza._id===id){
                setName(pizza.name)
                setDesc(pizza.description)
                setCategory(pizza.category)
                setSmallprice(pizza.prices[0]['small'])
                setMediumprice(pizza.prices[0]['medium'])
                setLargeprice(pizza.prices[0]['large'])
                setImage(pizza.image)

            }else{
                dispatch(getPizzaById(id))

            }
            
        }else{
            dispatch(getPizzaById(id))

        }
        


    },[pizza,dispatch]);


    const submitHandler=(e)=>{
        e.preventDefault();
        const updatedPizza={
            _id:id,
          name,
          image,
          desc,category,
          prices:{
            small:smallprice,
            medium:mediumprice,
            large:largeprice
          }
        }
        console.log(updatedPizza)
        dispatch((editPizza(updatedPizza)))
    
    
      }
    

   


  return (
    <div>
        <div style={{textAlign:'left'}}>
        <h2>Edit Pizza</h2>
        {loading && (<Loading/>)}
        {error && (<Error error='something went wrong'/>) }
        {editerror && (<Error error='Error while updating'/>)}
        {editloading && (<Loading/>)}
        {editsuccess && (<Success success='pizza Edited succesfully'/>)}
        
        <form onSubmit={submitHandler}>
          <input type='text' className='form-control' value={name} placeholder='pizza name' onChange={(e)=>setName(e.target.value)}/>
          <input type='text' className='form-control' value={smallprice} placeholder='small price' onChange={(e)=>setSmallprice(e.target.value)}/>
          <input type='text' className='form-control' value={mediumprice} placeholder='medium price' onChange={(e)=>setMediumprice(e.target.value)}/>
          <input type='text' className='form-control' value={largeprice} placeholder='large price' onChange={(e)=>setLargeprice(e.target.value)}/>
          <input type='text' className='form-control' value={image} placeholder='image url' onChange={(e)=>setImage(e.target.value)}/>
          <input type='text' className='form-control' value={desc} placeholder='Description' onChange={(e)=>setDesc(e.target.value)}/>
          <input type='text' className='form-control' value={category} placeholder='category' onChange={(e)=>setCategory(e.target.value)}/>
          <button type='submit' className='btn mt-3'>Update Pizza</button>





        </form>
      </div>
       
    </div>
  )
}

export default Editpizza