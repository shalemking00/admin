import "./App.css";
import Home from "./components/Home";
import Navbar from "./components/Navbar";
import { BrowserRouter, Route, Link, Routes, Navigate } from "react-router-dom";
import Cart from "./components/Cart";
import Register from "./components/Register";
import Login from "./components/Login";
import "bootstrap";
import { useSelector } from "react-redux";
import Orders from "./components/Orders";
import Admin from "./components/Admin";


function App() {
  const user = useSelector((state) => state.LoginReducer);
  const { currentUser } = user;
  return (
    <div className="App">
      <Navbar />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route path="/register" element={<Register />} />

          <Route exact path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path='/orders' element={<Orders/>}/>
          <Route path='/admin/*' element={<Admin/>}/>
         
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
