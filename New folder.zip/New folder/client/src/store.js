import {combineReducers} from "redux"
import { createStore,applyMiddleware } from "redux"
import thunk from "redux-thunk"
import {composeWithDevTools} from 'redux-devtools-extension'
import { getAllPizzasReducer } from "./reducers/pizzaReducers"
import { cartReducer } from "./reducers/cartReducer"
import { userReducer } from "./reducers/userReducer"
import { LoginReducer } from "./reducers/LoginReducer"
import {  orderReducer } from "./reducers/orderReducer"
import {getOrderReducer} from './reducers/getOrderReducer'
import { addpizzaReducer } from "./reducers/addpizzaReducer"
import { getpizzabyidReducer } from "./reducers/getpizzabyidReducer"
import { editPizzaReducer } from "./reducers/editPizzaReducer"
import { allOrdersReducer } from "./reducers/allOrdersReducer"

const finalReducer=combineReducers({
    getAllPizzasReducer:getAllPizzasReducer,
    cartReducer:cartReducer,
    userReducer:userReducer,
    LoginReducer:LoginReducer,
    orderReducer:orderReducer,
    getOrderReducer:getOrderReducer,
    addpizzaReducer:addpizzaReducer,
    getpizzabyidReducer:getpizzabyidReducer,
    editPizzaReducer:editPizzaReducer,
    allOrdersReducer:allOrdersReducer
});

const cartItems=localStorage.getItem('cartItems')?JSON.parse(localStorage.getItem('cartItems')):[]
const loggedUser=localStorage.getItem('currentUser')?JSON.parse(localStorage.getItem('currentUser')):null

    

const initialState={
    cartReducer:{
        cartItems:cartItems

    },
    LoginReducer:{
        currentUser:loggedUser
    }
    
}

const composeEnhancer=composeWithDevTools({})

const store=createStore(finalReducer,initialState,composeEnhancer(applyMiddleware(thunk)))

export default store;
