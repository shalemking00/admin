export const editPizzaReducer = (state={},action) => {
    switch (action.type) {
        case 'EDIT_PIZZA_REQUEST':
            return{
                editloading:true
            }
        case 'EDIT_PIZZA_SUCCESS':
            return{
                editloading:false,
                editsuccess:true
            }
        case 'EDIT_PIZZA_FAILED':
            return{
                editloading:false,
                editerror:action.payload
            }
        
        default:
            return state;
    }
}

