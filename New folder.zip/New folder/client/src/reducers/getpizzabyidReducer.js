export const getpizzabyidReducer=(state={pizza:[]},action)=>{
    switch (action.type) {
        case 'GET_PIZZABYID_REQUEST':
            return {
                loading:true,
                ...state}
        case 'GET_PIZZABYID_SUCCESS':
            return{
                loading:false,
                pizza:action.payload
            }
        case 'GET_PIZZABYID_FAILED':
            return{
                loading:false,
                error:action.payload
            }

        default:
           return state;
    }
}