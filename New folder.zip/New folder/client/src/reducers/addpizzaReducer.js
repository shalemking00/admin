export const addpizzaReducer = (state={},action) => {
    switch (action.type) {
        case 'ADD_PIZZA_REQUEST':
            return{
                loading:true
            }
        case 'ADD_PIZZA_SUCCESS':
            return{
                loading:false,
                success:true
            }
        case 'ADD_PIZZA_FAILED':
            return{
                loading:false,
                error:action.payload
            }
        
        default:
            return state;
    }
}

