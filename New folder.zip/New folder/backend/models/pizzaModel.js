const mongoose=require('mongoose');
  const { Schema } = mongoose;

  const pizzaSchema = new Schema({
    name:  {
        type:String,
        required:true 
    },
    varients:[],
    prices:[],
    category:{
        type:String,
        required:true
    },
    Image:{
        type:String
    },
    description:{
        type:String
    },
    
        
    


    
  },{
    timestamps:true,
  }
  );

  const PizzaModel=mongoose.model('pizzas',pizzaSchema);
  module.exports=PizzaModel