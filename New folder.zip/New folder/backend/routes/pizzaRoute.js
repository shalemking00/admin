const express=require('express')
const router=express.Router();
const PizzaModel=require('../models/pizzaModel')

router.get('/getAllpizzas',async(req,res)=>{
    try {
        const allpizzas=await PizzaModel.find({})
        res.json(allpizzas)

        
        
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})

router.post('/addpizza',async(req,res)=>{
    try {
        const pizza=req.body.pizza

    const newPizza= new PizzaModel({
        name:pizza.name,
        image:pizza.image,
        varients:['small','medium','large'],
        description:pizza.desc,
        category:pizza.category,
        prices:[pizza.prices]
    })
    await newPizza.save();
    res.send('new pizza added succesfully')
        
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})

router.post('/getpizzabyid',async(req,res)=>{
    const pizzaId=req.body.id
    console.log(pizzaId)
    try {
        const pizza=await PizzaModel.findById(pizzaId);
        res.send(pizza);
        console.log(pizza)
        
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})


router.post('/editpizza',async(req,res)=>{
    const editedPizza=req.body.updatedPizza
    try {
        const pizza=await PizzaModel.findOne({_id:editedPizza._id})
        pizza.name=editedPizza.name
        pizza.description=editedPizza.description
        pizza.image=editedPizza.image
        pizza.category=editedPizza.category
        pizza.prices=[editedPizza.prices]

        await pizza.save()
        res.send('details updated  sucessfully');

        
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})

router.post('/deletepizza',async(req,res)=>{
    const pizzaId=req.body.id
    try {
        const response=await PizzaModel.findOneAndDelete({_id:pizzaId})
        res.send('pizza Deleted Succesfully')
        console.log(response)
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})



module.exports=router