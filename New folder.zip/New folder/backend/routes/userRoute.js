const express=require('express')
const router=express.Router();
const UserModel=require('../models/register')


router.post('/register',async(req,res)=>{
    const {name,email,password}=req.body

    const newUser= new UserModel({name,email,password})
    try {
        await newUser.save()
        res.status(201).send('user Registered Successfully')

        
    } catch (error) {
        console.log(error)
        res.status(400).json({message:error})
        
    }
});

router.post('/login',async(req,res)=>{
    const{email,password}=req.body;
    try {
        const user=await UserModel.find({email,password});
        if(user.length>0){
            const currentUser={
                name:user[0].name,
                email:user[0].email,
                isAdmin:user[0].isAdmin,
                _id:user[0]._id
            }
            res.send(currentUser);
        }else{
            return res.status(404).json({message:'user Login Failed'});
        }
        
    } catch (error) {
        console.log(error);
        return res.status(404).json({message:'Something went Wrong'});
        
    }

})

module.exports=router