const express=require('express');
const router=express.Router()
const stripe=require('stripe')("sk_test_51KksavSFsKttunbCdByvvhoL21ncEw4g53ZscbnwnKdyaOm2ndWACHxmjLBoOgDePDFLARGRObCaUYG7lptWa2gH002a50822m")
const { v4: uuidv4 } = require('uuid');
const Order=require('../models/orderModel')


router.post('/placeorder',async(req,res)=>{
    const{token,subtotal,currentUser,cartItems}=req.body

    try {
        const customer=await stripe.customers.create({
            email:token.email,
            source:token.id
        })



        const payment=await stripe.paymentIntents.create({
            amount:subtotal*100,
            currency:'inr',
            customer:customer.id,
            receipt_email:token.email

        },{
            idempotencyKey:uuidv4()
        });
        if(payment){
            const{address_country,address_city,address_line1,address_zip}=token.card
            const newOrder=new Order({
                name:currentUser.name,
                email:currentUser.email,
                userid:currentUser._id,
                orderItems:cartItems,
                orderAmount:subtotal,
                shippingAddress:{
                    country:address_country,
                    city:address_city,
                    street:address_line1,
                    zip:address_zip

                },
                transactionId:payment.id
            })
            newOrder.save()
            res.send('Payment Successfull');
        }else{
            res.send('payment failed');
        }
    } catch (error) {
        console.log(error);
        return res.status(400).json({message:'something went wrong '+ error});
    }
   

});

router.post('/myorders',async(req,res)=>{
    const {userid}=req.body
    try {
        const orders=await Order.find({userid:userid}).sort({_id:-1})
        res.send(orders);
        
    } catch (error) {
        console.log(error)
        res.send('something went wrong')
        
    }
})

router.get('/allorders',async(req,res)=>{
    try {
        const orders=await Order.find({})
        res.send(orders)
    } catch (error) {
        
        console.log(error)
        res.send('something went wrong')
    }
})

router.post('/deliverorder',async(req,res)=>{
    const orderId=req.body.id
    try {
        const order= await Order.findOne({_id:orderId})
        order.isDelivered=true
        await order.save()
        res.send('Order delivered succesfull')
            
    } catch (error) {
        console.log(error)
        res.send('something went wrong')
        
    }
    
})

module.exports=router