import  firebase from "firebase/compat/app"
import { getStorage } from "firebase/storage";
const firebaseConfig = {
    apiKey: "AIzaSyA_J4b4VKat1-9050Kcm7jtsoDcg7hSe_M",
    authDomain: "netflix-bd2bd.firebaseapp.com",
    projectId: "netflix-bd2bd",
    storageBucket: "netflix-bd2bd.appspot.com",
    messagingSenderId: "314175891463",
    appId: "1:314175891463:web:244a4bf4ea4ed82602a2a2",
    measurementId: "G-VE88NP8Y6G"
  };
  firebase.initializeApp(firebaseConfig)
  const storage=getStorage()
  export default storage