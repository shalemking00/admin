

import "./App.css";
import Home from "./pages/home/Home";
import { BrowserRouter , Routes, Route } from "react-router-dom";
 import ListList from "./pages/listList/ListList";
import User from "./pages/user/User";
import UserList from './pages/userList/UserList'
import NewUser from "./pages/newUser/NewUser";
 import MovieList from "./pages/movieList/MovieList";
 import Movie from "./pages/movie/Movie";
 import NewMovie from "./pages/newMovie/NewMovie";
import Login from "./pages/login/Login";
import { AuthContext } from "./context/authContext/AuthContext";
import {useContext} from 'react'
import {Navigate} from 'react-router-dom'
import List from "./pages/list/List";
import NewList from "./pages/newList/NewList";


function App() {
  const {user}=useContext(AuthContext);
  return (
    <BrowserRouter>
     
      <Routes>
        
        <Route exact path="/" element= {user ? <Home /> : <Navigate to="/login" />}/>
        <Route path="/login" element={user?<Navigate to='/'/>:<Login/>}/>
        {user && (
          <>
            <Route exact path="/" element={<Home/>}/>
            <Route path='/movies' element={<MovieList/>}/>
            <Route path="/movies/:movieId" element={<Movie/>}/>
            <Route path="/newMovie" element={<NewMovie />}/>
            <Route path="/lists" element={<ListList />}/>
            <Route path="/list/:listId" element={<List />}/>
            <Route path="/newlist" element={ <NewList />}/>
            <Route path="/users" element={<UserList />}/>
             
            <Route path="/users/:userId" element={ <User />}/>
            
            <Route path="/newUser" element={ <NewUser />}/>
            
          </>
        )}
        
       
             
      </Routes>
    </BrowserRouter>
  );
}
    
export default App
    
      
        
       