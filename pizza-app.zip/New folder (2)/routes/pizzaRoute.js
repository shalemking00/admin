const express=require('express')
const router=express.Router();
const PizzaModel=require('../models/pizzaModel')

router.get('/getAllpizzas',async(req,res)=>{
    try {
        const allpizzas=await PizzaModel.find({})
        res.json(allpizzas)

        
        
    } catch (error) {
        console.log(error)
        return res.status(400).json({message:error});
        
    }
})
module.exports=router