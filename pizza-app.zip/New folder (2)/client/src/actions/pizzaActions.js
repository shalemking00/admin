import axios from "axios";
export const getAllPizzas=async dispatch=>{
    dispatch({type:'GET_PIZZAS_REQUEST'})
    try {
        const pizzas=await axios.get('http://localhost:7000/api/pizzas/getAllpizzas')
        console.log(pizzas);
        dispatch({type:'GET_PIZZAS_SUCCESS',payload:pizzas.data})
        
    } catch (error) {
        dispatch({type:'GET_PIZZAS_FAILED',payload:error});
        console.log(error)
    }
}