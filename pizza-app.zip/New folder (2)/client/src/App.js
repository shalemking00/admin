
import './App.css';
import Home from './components/Home';
import Navbar from './components/Navbar';
import {BrowserRouter,Route,Link,Routes} from "react-router-dom" 
import Cart from './components/Cart';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Home/>}/>
        <Route path='/cart' element={<Cart/>}/>
      </Routes>
        
      </BrowserRouter>
      
      
        
    </div>
  );
}

export default App;
