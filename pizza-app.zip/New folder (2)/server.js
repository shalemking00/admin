const express=require("express");
const app=express();
const cors=require('cors')
const db=require("./db")
const PizzaModel=require("./models/pizzaModel")
const pizzaRoute=require('./routes/pizzaRoute')



app.use(express.json());
app.use(cors())




app.use('/api/pizzas/',pizzaRoute);

app.get('/',(req,res)=>{
    res.send("welcome to backend")
})


    




const port=process.env.PORT||7000;


app.listen(port,()=>{
    console.log("server running on port",port);
})